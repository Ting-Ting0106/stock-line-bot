import { Client, middleware, WebhookEvent } from '@line/bot-sdk';
import { Request, Response } from 'express';
import { getBuyCandidates, getSellRecommendations } from './stockAnalysis';

const client = new Client({
  channelAccessToken: process.env.LINE_CHANNEL_ACCESS_TOKEN!,
  channelSecret: process.env.LINE_CHANNEL_SECRET!,
});

export const handleWebhook = [
  middleware({
    channelAccessToken: process.env.LINE_CHANNEL_ACCESS_TOKEN!,
    channelSecret: process.env.LINE_CHANNEL_SECRET!,
  }),
  async (req: Request, res: Response) => {
    const events: WebhookEvent[] = req.body.events;
    await Promise.all(events.map(handleEvent));
    res.sendStatus(200);
  },
];

async function handleEvent(event: WebhookEvent) {
  if (event.type !== 'message' || event.message.type !== 'text') return;
  const msg = event.message.text;

  let reply = '';
  if (msg.includes('我要買什麼')) {
    const list = await getBuyCandidates();
    reply = list.length > 0 ? list.join('\n') : '目前沒有建議買入的股票';
  } else if (msg.includes('我的持股')) {
    const list = await getSellRecommendations();
    reply = list.length > 0 ? list.join('\n') : '目前沒有建議賣出的股票';
  } else {
    reply = '請輸入「我要買什麼」或「我的持股」來查詢。';
  }

  await client.replyMessage(event.replyToken!, {
    type: 'text',
    text: reply,
  });
}
