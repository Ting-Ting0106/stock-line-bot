import 'dotenv/config';
import express from 'express';
import { handleWebhook } from './line';
import { dailyPushJob } from './scheduler';

const app = express();
app.use(express.json());
app.post('/webhook', handleWebhook);

app.listen(3000, () => {
  console.log('LINE Bot server running on port 3000');
  dailyPushJob();
});
