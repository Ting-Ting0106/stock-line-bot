import cron from 'node-cron';
import { Client } from '@line/bot-sdk';
import { getBuyCandidates } from './stockAnalysis';

const client = new Client({
  channelAccessToken: process.env.LINE_CHANNEL_ACCESS_TOKEN!,
  channelSecret: process.env.LINE_CHANNEL_SECRET!,
});

export function dailyPushJob() {
  cron.schedule('10 9 * * 1-5', async () => {
    const list = await getBuyCandidates();
    if (list.length === 0) return;
    await client.pushMessage(process.env.LINE_USER_ID!, {
      type: 'text',
      text: '今天可關注的半導體股：\n' + list.join('\n'),
    });
  });
}
