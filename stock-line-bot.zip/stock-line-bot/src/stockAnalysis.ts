import { readSheet } from './googleSheet';

export async function getBuyCandidates(): Promise<string[]> {
  const rows = await readSheet('買進建議');
  const list: string[] = [];
  for (let i = 1; i < rows.length; i++) {
    const [id, name, price, rsi, kd, action] = rows[i];
    if (action === '可關注') list.push(`${id} ${name} 價格:${price}`);
  }
  return list;
}

export async function getSellRecommendations(): Promise<string[]> {
  const rows = await readSheet('持股追蹤');
  const list: string[] = [];
  for (let i = 1; i < rows.length; i++) {
    const [id, name, cost, amount, notify, status] = rows[i];
    if (status === '可考慮賣出') list.push(`${id} ${name} 成本:${cost}`);
  }
  return list;
}
